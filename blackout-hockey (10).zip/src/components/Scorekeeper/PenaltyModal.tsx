import { useState } from 'react';
import { AlertTriangle, X, Check } from 'lucide-react';
import { Player } from '../../types';

interface PenaltyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (penaltyData: {
    team: 'TOR' | 'MTL';
    player: string;
    reason: string;
    minutes: number;
  }) => void;
  homeTeam?: string;
  awayTeam?: string;
  homeRoster?: Player[];
  awayRoster?: Player[];
}

const COMMON_PENALTIES = [
  'Tripping (Pootje haken)',
  'Hooking (Vasthouden)',
  'Slashing (Beshopen)',
  'High Sticking (Hoge stick)',
  'Roughing (Ruw spel)',
  'Boarding (Boarding)',
  'Interference (Hinderen)',
  'Cross-Checking',
  'Delay of Game',
  'Misconduct',
  'Andere straf'
];

export default function PenaltyModal({ 
  isOpen, 
  onClose, 
  onSubmit,
  homeTeam = 'TORONTO (TOR)',
  awayTeam = 'MONTREAL (MTL)',
  homeRoster = [],
  awayRoster = []
}: PenaltyModalProps) {
  const [team, setTeam] = useState<'TOR' | 'MTL'>('TOR');
  const [player, setPlayer] = useState('');
  const [reason, setReason] = useState(COMMON_PENALTIES[0]);
  const [minutes, setMinutes] = useState<number>(2);

  if (!isOpen) return null;

  const activeRoster = team === 'TOR' ? homeRoster : awayRoster;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      team,
      player: player.trim(),
      reason,
      minutes,
    });
    setPlayer('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[100] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-[#222222] border border-[#333] rounded-2xl w-full max-w-md p-5 shadow-2xl text-white animate-in fade-in zoom-in-95 duration-150">
        <div className="flex items-center justify-between border-b border-[#333] pb-3 mb-4">
          <div className="flex items-center gap-2 text-red-400 font-bold text-lg">
            <AlertTriangle className="w-5 h-5" />
            <span>STRAF REGISTREREN</span>
          </div>
          <button 
            onClick={onClose}
            className="text-gray-400 hover:text-white p-1 rounded-lg hover:bg-[#333] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* Team Selection */}
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase mb-1.5 font-bold">Team met straf</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                className={`py-2.5 rounded-lg font-bold text-sm transition-all border ${
                  team === 'TOR' 
                    ? 'bg-blue-600 text-white border-blue-400 shadow-md scale-[1.02]' 
                    : 'bg-[#181818] text-gray-400 border-[#333] hover:text-white'
                }`}
                onClick={() => setTeam('TOR')}
              >
                {homeTeam}
              </button>
              <button
                type="button"
                className={`py-2.5 rounded-lg font-bold text-sm transition-all border ${
                  team === 'MTL' 
                    ? 'bg-red-600 text-white border-red-400 shadow-md scale-[1.02]' 
                    : 'bg-[#181818] text-gray-400 border-[#333] hover:text-white'
                }`}
                onClick={() => setTeam('MTL')}
              >
                {awayTeam}
              </button>
            </div>
          </div>

          {/* Player */}
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase mb-1 font-bold">
              Speler (# of Naam) <span className="text-red-400">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="bijv. #24"
              value={player}
              onChange={e => setPlayer(e.target.value)}
              className="w-full bg-[#181818] border border-[#333] focus:border-red-400 text-white rounded-lg px-3 py-2 text-sm outline-none transition-colors"
            />
            {activeRoster.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-1.5">
                {activeRoster.map(p => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => setPlayer(`${p.number} ${p.name}`)}
                    className="text-[10px] bg-[#2a2a2a] hover:bg-red-500 hover:text-white text-gray-300 px-2 py-0.5 rounded transition-colors"
                  >
                    {p.number} {p.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Penalty Reason */}
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase mb-1 font-bold">
              Type Straf / Reden
            </label>
            <select
              value={reason}
              onChange={e => setReason(e.target.value)}
              className="w-full bg-[#181818] border border-[#333] focus:border-red-400 text-white rounded-lg px-3 py-2 text-sm outline-none transition-colors"
            >
              {COMMON_PENALTIES.map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>

          {/* Penalty Duration */}
          <div>
            <label className="block text-xs font-mono text-gray-400 uppercase mb-1.5 font-bold">
              Tijdsduur (Minuten)
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[2, 5, 10].map(m => (
                <button
                  key={m}
                  type="button"
                  className={`py-2 rounded-lg font-bold text-xs transition-all border ${
                    minutes === m
                      ? 'bg-red-500/20 text-red-400 border-red-500 font-extrabold'
                      : 'bg-[#181818] text-gray-400 border-[#333] hover:text-white'
                  }`}
                  onClick={() => setMinutes(m)}
                >
                  {m} Min ({m === 2 ? 'Minor' : m === 5 ? 'Major' : 'Misconduct'})
                </button>
              ))}
            </div>
          </div>

          {/* Submit */}
          <div className="flex gap-2 pt-2 border-t border-[#333] mt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-lg border border-[#444] text-gray-300 font-bold text-sm hover:bg-[#333] transition-colors"
            >
              Annuleren
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-sm transition-all flex items-center justify-center gap-1.5 shadow-lg active:scale-95"
            >
              <Check className="w-4 h-4" />
              Straf Opslaan
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
